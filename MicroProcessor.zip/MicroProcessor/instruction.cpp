#pragma once
class Instruction {
    public:
        virtual void executeInstruction() {
            
        }
};
